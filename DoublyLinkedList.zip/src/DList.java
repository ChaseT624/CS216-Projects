import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Class name: DList
 * Chase Tiberi
 * Hw1
 *
 * A generic doubly-linked list class
 */
public class DList<E> implements Iterable<E> {
    //member variables 
    private int count;
    private DNode<E> head;
    private DNode<E> tail;

    
    class DNode<E> {
        E data;
        DNode next;
        DNode prev;
        
        
        /**
         * construct a double linked node
         * @param d     data being put in the node     
         * @param n     link to next node in list
         * @param p     link to previous node in list
         */
        public DNode(E d, DNode<E> n, DNode<E> p) {
            data = d;
            next = n;
            prev = p;
        }
    }
    /**
     * Construct a empty list by initializing variables 
     */
    public DList() {    
    count = 0;
    head = tail = new DNode<E>(null, null ,null);
    
    }

    /**
     * return a string of the list from front to back
     * @return string of the list from front to back
     */
    public String toString() {
        String str = "[ ";
        DNode<E> ptr = head.next;
        while (ptr != null) {
        	str = str + ptr.data + " " ;
        	ptr = ptr.next;
        }
        str = str + "]";
        return str;
    }

    /**
     * return a string of the list from back to front
     * @return string of the list from back to front
     */
    public String toStringBackwards() {
        String str = "[ ";
        DNode<E> ptr = tail;
        while (ptr.prev != null) {
            str = str + ptr.data + " " ;
            ptr = ptr.prev;
        }
        str = str + "]";
        return str;
    }
    
    /**
     * adds the given item to the end of the list
     * @param item         item to be added to the end of the list
     */
    public void add(E item) {    
    if (count == 0) {
    	tail = new DNode<E>(item,null, head);
    	head.next = tail;
    }
    else {
    	DNode<E> newNode = new DNode<E>(item, null,tail);
    	tail.next = newNode;
    	tail = newNode;
    }
    count++;
    }
  
    
    /**
     * adds the given item to the specified index in the list
     * @param index        index where item should be added
     * @param item         item to be added to the list
     * 
     */
    public void add(int index, E item) throws IndexOutOfBoundsException{    
    	if (index < 0 || index > count)
    		new IndexOutOfBoundsException();
    	else if (count == 0 || count == index) {
    		add(item);
    	}
    	else { 
        	DNode<E> ptr = head;
            for (int i = 0; i < index; i++) {
            	ptr = ptr.next;
            }
    	    DNode<E> newNode = new DNode<E> (item, ptr, ptr.prev);
    	    ptr.prev = newNode; 
    	    newNode.prev.next = newNode; 
    	    
    	    count++;
    	}
    	
    }
    
    /**
     * clears the list of all data
     */
    public void clear() {
    DNode<E> ptr = head;
    while (ptr != null) {
    	DNode <E> tmp = ptr;
    	ptr = ptr.next;
    	tmp.next = null;
    	tmp.prev = null;		
    }
    head = tail = new DNode<E>(null, null ,null);
    count = 0;
    }

    /**
     * get the item at the specified index as long as the index is valid
     * @param index        index of what item to return
     * @return the item at the specified index if the index is valid
     */
    public E get(int index) {
    	if (index <= 0 || index > count)
    		return null;
    	int indexCount = count; 
    	DNode<E> ptr = tail;
        while (indexCount != index) {
        	indexCount--;
        	ptr = ptr.prev;
        }
        return ptr.data;
    }

    /**
     * replace the item at the specified index as long as the index is valid, 
     * and return the data being removed
     * @param index         index of what item to replace
     * @param item            item to be put at the given index
     * @return the data that was removed from the index as long as the index is valid
     */
    public E set(int index, E item) {
    	if (index <= 0 || index > count)
    		return null;
    	int indexCount = count; 
    	DNode<E> ptr = tail;
        while (indexCount != index) {
        	indexCount--;
        	ptr = ptr.prev;
        }
        E data = ptr.data;
        ptr.data = item;
        return data;
    }

    /**
     * checks to see whether the list contains the specified item
     * @param item           item being checked to see if it is in the list
     * @return true if the specified item is in the list
     */
    public boolean contains(E item) {
    	 DNode<E> ptr = tail;
         while (ptr.prev != null) {
        	 if (ptr.data == item)
        		 return true;
        	 ptr = ptr.prev;
         }
    	return false;
    }

    /**
     * checks for and returns the first index of the specified item, returns -1 if the item is not in the list
     * @param item            item being checked for its first index
     * @return the first index of the specified item, or -1 if the item is not in the list
     */
    public int indexOf(E item) {
    	int indexCount = 0; 
    	DNode<E> ptr = head;
         while (ptr.next != null) {
        	 if (ptr.data == item) {
        		 return indexCount;
        	 }
        	 ptr = ptr.next;
        	 indexCount++;
         }
    	return -1;
    }


    /**
     * checks for and returns the last index of the specified item, returns -1 if the item is not in the list
     * @param item            item being checked for its last index
     * @return the last index of the specified item, or -1 if the item is not in the list
     */
    public int lastIndexOf(E item) {
    	int indexCount = count; 
    	DNode<E> ptr = tail;
         while (ptr.prev != null) {
        	 if (ptr.data == item) {
        		 return indexCount;
        	 }
        	 ptr = ptr.prev;
        	 indexCount--;
         }
    	return -1;
    }

    /**
     * returns the number of items on the list
     * @return the number of items on the list
     */
    public int size() {
        return count;
    }

    /**
     * checks to see if the list is empty
     * @return true if list is empty
     */
    public boolean empty() {
        return count == 0;
    }
    
    public E[] toArray() {
    	E[] dListArray = (E[]) new Object[count];
    	int index = 0;
    	DNode<E> ptr = head.next;
    	while(ptr != null) {
    		dListArray[index] = ptr.data;
    		ptr = ptr.next;
    		index++;
    	}
    return dListArray;
    }
    
    public E remove(int index) {
    	if (index <= 0 || index > count) {
    		return null;
    	}
    	else if(index == count) {
    		tail.prev.next = null;
    		tail = tail.prev;
    		count--;
    		return tail.data;
    	}
    	else {
    		int indexCount = 0;
    		DNode<E> ptr = head;
    		while (indexCount != index) {
           	 indexCount++;
           	 ptr = ptr.next;
            }
    		ptr.prev.next = ptr.next;
    		ptr.next.prev = ptr.prev;
    		count--;
    		return ptr.data;
    	}
    }

    public boolean remove(E item) {
    	if (contains(item)) {
    		DNode<E> ptr = head;
    		while (ptr.data != item) {
    			ptr = ptr.next;
    		}
    		ptr.prev.next = ptr.next;
    		ptr.next.prev = ptr.prev;
    		count--;
    		return true;
    	}
    	else
    		return false;
    }
    
    public void removeRange(int fromIndex, int toIndex) {
    	int size = count;
    	if (fromIndex <= 0)
    		fromIndex = 1;
    	if (toIndex > count)
    		toIndex = count;
    	if(fromIndex > toIndex)
    		throw new IllegalArgumentException("Start index can't be greater than toIndex");
    	if(fromIndex == 1 && toIndex == count)
    		clear();
    	else {
    		int indexCount = 0;
    		DNode<E> ptr = head;
    		while(indexCount < fromIndex) {
    			ptr = ptr.next;
    			indexCount++;
    	}
    		DNode<E> hold = ptr.prev;
    		while(fromIndex <= toIndex) {
    			DNode<E> tmp = ptr;
    			ptr = ptr.next;
    			tmp.next = tmp.prev = null;
    			count--;
    			fromIndex++;
    		}
    		
    		if(toIndex == size) {
    			hold.next = null;
    			hold = tail;
    		}
    		else {
    			hold.next = ptr;
    			ptr.prev = hold;
    		}
    	}
    }

    public void addAll(int index, Iterable<E> collection) {
    	DListIterator coll = (DList<E>.DListIterator) collection.iterator();
    	int size = count;
    	if (index <= 0 || index > count)
    		throw new IndexOutOfBoundsException("Nah bro");
    	else {
    		while (coll.hasNext()){
    			if(index == size) {
    			DNode<E> newNode = new DNode<E>(coll.next(), null,tail);
    	    	tail.next = newNode;
    	    	tail = newNode; }
    			else {
    				DNode<E> ptr = head;
    	            for (int i = 0; i < index; i++) {
    	            	ptr = ptr.next;
    	            }
    	    	    DNode<E> newNode = new DNode<E> (coll.next(), ptr, ptr.prev);
    	    	    ptr.prev = newNode; 
    	    	    newNode.prev.next = newNode;
    			}
    		count++;
    		}
    		
    	}
    }
    public Iterator<E> iterator() {
		return new DListIterator();
	}
    
    private class DListIterator implements Iterator<E> {
    		int iNext;
    		DNode<E> ptr;
			
    	public DListIterator() {
			iNext = 0;
			ptr = head;
		}
		public boolean hasNext() {
			if (iNext < count) 
				return true;
			else 
				return false;
		}

		public E next() {
		if (iNext < count) {
			  ptr = ptr.next;
			  iNext++;
			  return ptr.data;
		}
		else {
               throw new NoSuchElementException("iterator at the end");
           }
		}
	
}
	
	

}

