import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class DListTest {

    private DList<String> dEmpty;
    private DList<String> dSingle;
    private DList<String> dMulti;
    
    @Before
    public void setUp() throws Exception {
    dEmpty = new DList<String>();
    dSingle = new DList<String>();
    dMulti = new DList<String>();
    }

    @Test
    public void testToString() {
        assertEquals("[ ]", dEmpty.toString());
        dSingle.add("d1");
        assertEquals("[ d1 ]", dSingle.toString());
        dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        assertEquals("[ d3 d2 d1 ]", dMulti.toString());
    }

    @Test
    public void testToStringBackwards() {
        assertEquals("[ ]", dEmpty.toStringBackwards());
        dSingle.add("d1");
        assertEquals("[ d1 ]", dSingle.toStringBackwards());
        dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        assertEquals("[ d1 d2 d3 ]", dMulti.toStringBackwards());
    }

    @Test
    public void testAddE() {
        dMulti.add("d3");
        assertEquals("[ d3 ]", dMulti.toString());
        assertEquals("[ d3 ]", dMulti.toStringBackwards());
        dMulti.add("d2");
        assertEquals("[ d3 d2 ]", dMulti.toString());
        assertEquals("[ d2 d3 ]", dMulti.toStringBackwards());
        dMulti.add("d1");
        assertEquals("[ d3 d2 d1 ]", dMulti.toString());
        assertEquals("[ d1 d2 d3 ]", dMulti.toStringBackwards());
        
    }

    @Test
    public void testAddIntE() {
        dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        dMulti.add(2, "d4");
        assertEquals("[ d3 d4 d2 d1 ]", dMulti.toString());
        assertEquals("[ d1 d2 d4 d3 ]", dMulti.toStringBackwards());
        dMulti.add(3, "d5");
        assertEquals("[ d3 d4 d5 d2 d1 ]", dMulti.toString());
        assertEquals("[ d1 d2 d5 d4 d3 ]", dMulti.toStringBackwards());
        dMulti.add(1, "d6");
        assertEquals("[ d6 d3 d4 d5 d2 d1 ]", dMulti.toString());
        assertEquals("[ d1 d2 d5 d4 d3 d6 ]", dMulti.toStringBackwards());
        dMulti.add(12, "d12");
        assertEquals("[ d6 d3 d4 d5 d2 d1 ]", dMulti.toString());
        assertEquals("[ d1 d2 d5 d4 d3 d6 ]", dMulti.toStringBackwards());
    }

    @Test
    public void testClear() {
        dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        dMulti.clear();
        assertTrue("Returns true if the list is empty", dMulti.empty());
        assertEquals("[ ]", dMulti.toString());
        assertEquals("[ ]", dMulti.toStringBackwards());
        assertSame("Testing to see if size is correct",0, dMulti.size());
        assertTrue("Returns true if the list is empty", dMulti.empty());
    }

    @Test
    public void testGet() {
        assertSame("Testing to see if the right data is pulled", null, dEmpty.get(1));
        dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        dMulti.add("d3");
        assertSame("Testing to see if the right data is pulled", "d3" , dMulti.get(1));
    }

    @Test
    public void testSet() {
        dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        assertSame("Testing to see if the old data is pulled from the list", "d2", dMulti.set(2,"d4"));
        assertSame("Testing to see if the right data is put in the list", "d4", dMulti.get(2));
        assertEquals("[ d3 d4 d1 ]", dMulti.toString());
        assertEquals("[ d1 d4 d3 ]", dMulti.toStringBackwards());
    
    }

    @Test
    public void testContains() {
        dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        assertTrue("True if the list contains the specified item", dMulti.contains("d2"));
        assertTrue("True if the list contains the specified item", dMulti.contains("d1"));
        assertTrue("True if the list contains the specified item", dMulti.contains("d3"));
    }

    @Test
    public void testIndexOf() {
        assertSame("Testing to see if the last index is correct", -1, dEmpty.indexOf("d3"));
        dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        dMulti.add("d3");
        assertSame("Testing to see if the last index is correct", 1, dMulti.indexOf("d3"));
    }

    @Test
    public void testLastIndexOf() {
        assertSame("Testing to see if the last index is correct", -1, dEmpty.lastIndexOf("d3"));
        dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        dMulti.add("d3");
        assertSame("Testing to see if the last index is correct", 4, dMulti.lastIndexOf("d3"));
    }

    @Test
    public void testSize() {
        assertSame("Testing to see if size is correct",0, dEmpty.size());
        dSingle.add("d1");
        assertSame("Testing to see if size is correct",1, dSingle.size());
        dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        assertSame("Testing to see if size is correct",3, dMulti.size());
    }

    @Test
    public void testEmpty() {
        assertTrue("Returns true if the list is empty", dEmpty.empty());
        dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        dMulti.clear();
        assertTrue("Returns true if the list is empty", dMulti.empty());
    }

}