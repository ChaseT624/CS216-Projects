import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Iterator;

public class Tester {

	public static void main(String[] args) {
		DList x = new DList<String>();
		System.out.println(x.toStringBackwards());
		System.out.println(x.toString());
		x.add("Hi");
		x.add("Hey");
		x.add("Hrey");
		System.out.println(x.toString());
		System.out.println(x.toStringBackwards());
		System.out.println(x.size());
		System.out.println(x.contains("Hi"));
		System.out.println(x.contains("Brad"));
		System.out.println(x.lastIndexOf("Brad"));
		System.out.println(x.lastIndexOf("Hi"));
		System.out.println(x.get(1));
		System.out.println(x.set(1, "HIII"));
		System.out.println(x.toStringBackwards());
		System.out.println(x.indexOf("HIII"));
		DList x2 = new DList<String>();
		
		x2.add("boo");
		System.out.println(x2.size());
		x2.add("bye");
		System.out.println(x2.size());
		x2.add("hrey");
		System.out.println(x2.size());
		x2.add(2, "hrey2");
		x2.add("hrey");
		System.out.println(x2.toString());
		System.out.println(x2.toStringBackwards());
		System.out.println(x2.remove(2));
		System.out.println(x2.toString());
		System.out.println(x2.toStringBackwards());
		System.out.println(x2.remove(0));
		System.out.println(x2.toString());
		System.out.println(x2.toStringBackwards());
		System.out.println(x2.remove("bye"));
		System.out.println(x2.toString());
		System.out.println(x2.toStringBackwards());
		DList x3 = new DList<String>();
		x3.add("boo1");
		x3.add("boo2");
		x3.add("boo3");
		x3.add("boo4");
		x3.add("boo5");
		x3.add("boo6");
		x3.add("boo7");
		x3.add("boo8");
		x3.add("boo9");
		x3.add("boo10");
		x3.add("boo11");
		System.out.println(x3.size());
		System.out.println(x3.toString());
		System.out.println(x3.toStringBackwards());
		x3.removeRange(5, 9);
		System.out.println(x3.toString());
		System.out.println(x3.toStringBackwards());
		Object[] ar = x3.toArray();
		System.out.println(Arrays.toString(ar));
		x3.addAll(3, x2);
	
		System.out.println(x2.toString());
		System.out.println(x2.toStringBackwards());
		System.out.println(x3.toString());
		System.out.println(x3.toStringBackwards());
	/*	DList dMulti = new DList<String>();
		dMulti.add("d3");
        dMulti.add("d2");
        dMulti.add("d1");
        dMulti.add(2, "d4");
        assertEquals("[ d3 d4 d2 d1 ]", dMulti.toString());
        assertEquals("[ d1 d4 d2 d3 ]", dMulti.toStringBackwards()); */

	}

}
