import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

/**
 * Class name: Graph
 * Chase Tiberi
 * Hw10
 *
 * A class for creating Graphs*/
public class Graph {
	//member variables
	private ArrayList<Vertex> verts;
	private double[][] adjmat;
	private HashMap<String, Vertex> mapLabel;
	private ArrayList<Edge> edges;
	/**
	 * reads from files to create a graph
	 * @param vfile   file containing vertices
	 * @param efile   file containing edges
	 * @throws FileNotFoundException 
	 */
	public Graph(String vfile, String efile) throws FileNotFoundException {
		Scanner in = new Scanner(new File(vfile));
		int index = 0;
		verts = new ArrayList<Vertex>();
		mapLabel = new HashMap<String, Vertex>();
		while (in.hasNext()) {
			String lab = in.next();
			Vertex newV = new Vertex(lab, index);
			verts.add(newV);
			index++;
			mapLabel.put(lab, newV);
		}
		adjmat =  new double[verts.size()][verts.size()];
		in = new Scanner(new File(efile));
		edges = new ArrayList<Edge>();
		for (int i = 0; i < verts.size(); i++) {
			for (int j = 0; j < verts.size(); j++) {
				int nextI = in.nextInt();
				adjmat[i][j] = nextI;
				if (nextI != 0) {
					Edge newE = new Edge(verts.get(i), verts.get(j), nextI);
					edges.add(newE);
					verts.get(i).addAdj(newE);
				}
			}	
		}
		in.close();	
	}
	
	/**
	 * resets the vertices for algorithms
	 */
	public void resetVerts() {
		for (int i =0; i < verts.size(); i++) {
			verts.get(i).reset();
		}
	}
	
	/**
	 * return the arrayList of vertices
	 * @return the arrayList of vertices
	 */
	public ArrayList<Vertex> getVerts() {
		return verts;
	}
	
	/**
	 * returns the number of vertices
	 * @return the number of vertices
	 */
	public int nVerts() {
		return verts.size();
	}
	
	/**
	 * looks for vertex in the list with this label
	 * @param label      vertex being looked for
	 * @return vertex with label if found, null if not found
	 */
	public Vertex getVertex(String label) {
		return mapLabel.get(label);
	}
	
	/**
	 * looks for vertex in the list with this index
	 * @param index      vertex being looked for
	 * @return vertex with index if found, null if not found
	 */
	public Vertex getVertex(int index) {
		if (index < 0 || index >= verts.size()) {
			return null;
		}
		return verts.get(index);
	}
	
	/**
	 * looks for and returns edge with this starting and ending vertex
	 * @param vsrc      starting vertex
	 * @param vdst      ending vertex
	 * @return the edge if found, null if not
	 */
	public Edge getEdge(Vertex vsrc, Vertex vdst) {
		if (!vsrc.equals(null)) {
			return mapLabel.get(vsrc.label).getAdj(vdst.label);
		}
		return null;
	}
	
	/**
	 * looks for and returns edge with this starting and ending vertex labels
	 * @param src      starting vertex label
	 * @param dst      ending vertex label
	 * @return the edge if found, null if not
	 */
	public Edge getEdge(String src, String dst) {
		if (!getVertex(src).equals(null)) {
			return mapLabel.get(src).getAdj(dst);
		}
		return null;
	}
	
	/**
	 * returns the adjacency matrix
	 * @return the adjacency matrix
	 */
	public double[][] adjMatrix() {
		return adjmat;
	}
	
	/**
	 * makes a string representation of the graph
	 * @return a string representation of the graph
	 */
	public String toString() {
		String str = "[ Graph with " + verts.size() + " vertices ]\n";
		for (int i = 0; i < verts.size(); i++) {
			str += verts.get(i).toString() + "\n";
		}
		return str;
	}
	/**
	 * EdgeComp.java
	 * comparator for edge weights first then edge labels
	 */

	private class EdgeComp implements Comparator<Edge> {
	    public int compare(Edge e1, Edge e2) {
	        int diff = (int) (Math.round((e1.weight - e2.weight) * 100)) / 100;

	        // if weights of the two edges are the same, compare the edge labels
	        if (diff == 0) {
	            String eLabel1 = e1.getVsrc().label + e1.getVdst().label;
	            String eLabel2 = e2.getVsrc().label + e2.getVdst().label;

	            return eLabel1.compareTo(eLabel2);
	        }
	        else {
	            return diff;
	        }
	    }
	}

	
	/**
	 * (to be used for Kruskal's algorithm)
	 * internally convert directed graph to undirected graph 
	 * and return the edges sorted by weight and label in increasing order
	 *
	 * @return list of edges sorted by weight first then by edge label in increasing order
	 */
	public ArrayList<Edge> getEdgesUndirected() {
	    ArrayList<Edge> und = new ArrayList<Edge>();
	    EdgeComp edgeComp = new EdgeComp();

	    for (Edge e : edges) {
	        Vertex src = e.getVsrc();
	        Vertex dst = e.getVdst();
	        double w   = e.weight;

	        // each edge's src vertex is < dst vertex in 
			// undirected graph for easier comparison
	        String srcLabel = src.label;
	        String dstLabel = dst.label;

	        if (srcLabel.compareTo(dstLabel) > 0) {
	            Vertex tmp = src;
	            src = dst;
	            dst = tmp;
	        }

	        Edge ne = new Edge(src, dst, w);

	        // similar to one iteration of the insertion sort algorithm
	        // add the newly created edge to a correct location according 
			// to the sort order
	        int i = 0, eCount = und.size();
	        while (i < eCount && edgeComp.compare(ne, und.get(i)) > 0) {
	            ++i;
	        }
	        und.add(i, ne);
	    }

	    return und;
	}

	/**
	 * (to be used before applying Prim's algorithm)
	 * for each directed edge (v->u) add edge (u->v) if it doesn't exist
	 * if it does, update edge (u->v)'s weight to the weight of edge (v->u)
	 * update adjacency matrix accordingly
	 */
	public void toUndirected() {
		for (Vertex v : verts) {
			int vID = v.id;
			TreeMap<String, Edge> v_adj = v.getAdj();

			// for each edge (v->u)
			for (Edge e : v_adj.values()) {
				Vertex u = e.getVdst();
				double w = e.weight;
				int uID  = u.id;

				// add v as neighbor to dst if it isn't already a neighbor
				// edge (u->v)
				if (u.getAdj(v.label) == null) {
					Edge newE = new Edge(u, v, w);
					u.addAdj(newE);
					edges.add(newE);
				}
				// if edge (u->v) already exists, need to update it with the same weight
				else {
					Edge oldE = u.getAdj(v.label);
					oldE.weight = w;
				}

				// update the adjacency matrix accordingly
				adjmat[uID][vID] = w;
			}
		}
	}
	/**
	 * return the number of edges in the graph 
	 * @return number of edges in the graph 
	 */
	public int nEdges() {
		return edges.size();
	}

}
