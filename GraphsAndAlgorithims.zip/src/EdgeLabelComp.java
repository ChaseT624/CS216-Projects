import java.util.Comparator;

/**
 * Class name: EdgeLabelComp
 * Chase Tiberi
 * Hw9
 *
 * A class that compares destination vertex labels */
public class EdgeLabelComp implements Comparator<Edge> {

	/**
	 * compare and return the greater destination vertex label
	 * @param d1    edge 1
	 * @param d2    edge 2
	 * @return a value from 1 to -1 to show which value is larger
	 */
	public int compare(Edge e1, Edge e2) {
		StringComparator s = new StringComparator();
		return s.compare(e1.getVdst().label, e2.getVdst().label);
	}

}
