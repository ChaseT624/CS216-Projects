/**
 * Class name: Edge
 * Chase Tiberi
 * Hw9
 *
 * A class of Edge for Graphs */
public class Edge {
	//member variables
	private Vertex vsrc;
	private Vertex vdst;
	protected double weight;
	
	/**
	 * construct a edge using the vertices given and setting a default weight of 1
	 * @param vsrc     source vertex
	 * @param vdst     destination vertex
	 */
	public Edge(Vertex vsrc, Vertex vdst) {
		this(vsrc,vdst, 1);
	}
	
	/**
	 * construct a edge using the vertices given and weight given
	 * @param vsrc      source vertex
	 * @param vdst      destination vertex
	 * @param w         weight
	 */
	public Edge(Vertex vsrc, Vertex vdst, double w) {
		this.vsrc = vsrc;
		this.vdst = vdst;
		weight = w;
	}
	
	/**
	 * checks to see if this edge equals to given object
	 * @param obj     object being checked
	 * @return true if it is the same, false if not
	 */
	public boolean equals(Object obj) {
		if (obj instanceof Edge && vsrc == ((Edge) obj).getVsrc() && vdst == ((Edge) obj).getVdst()) {
			return true;
		}
		return false;
	}
	
	/**
	 * returns a string representation of the edge
	 * @return string representation of the edge 
	 */
	public String toString() {
		return vsrc.label +  "-" + vdst.label + " (" + weight +")";	
	}
	
	/**
	 * return the destination vertex
	 * @return the destination vertex
	 */
	public Vertex getVdst() {
		return vdst;
	}
	
	/**
	 * return the source vertex
	 * @return the source vertex
	 */
	public Vertex getVsrc() {
		return vsrc;
	}
	
	/**
	 * sets the weight with the provided weight
	 * @param w      the provided weight
	 */
	public void setWeight(double w) {
		weight = w;
	}
}
