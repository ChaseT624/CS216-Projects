import java.util.HashMap;
/**
 * Class name: Graph
 * Chase Tiberi
 * Hw10
 *
 * A class for creating disjointed sets*/

public class DisjointSet<E> {
	//member variable
	private HashMap<E, DSNode<E>> set;
	
	public DisjointSet(Iterable<E> items) {
		set = new HashMap<E, DSNode<E>>();
		for (E item: items) {
			DSNode<E> nn = new DSNode<E>(item);
			set.put(item, nn);	
		}
	}
	
	/**
	 * finds the DSNode related to the given item and sets its parent to the item and rank to 0 
	 * @param item      given item to be used 
	 */
	public void makeSet(E item) {
		DSNode<E> node = set.get(item);
		node.parent = item;
		node.rank = 0;
	}
	
	/**
	 * searches for and finds to representative for the given item
	 * @param item        item given 
	 * @return the representative for the given item 
	 */
	public E findRep(E item) {
		DSNode<E> node = set.get(item);
		if (!(node.parent.equals(item))) {
			node.parent = findRep(node.parent);
		}
		return node.parent;
	}
	
	public void Union(E d1, E d2) {
		DSNode<E> d1Node = set.get(d1);
		DSNode<E> d2Node = set.get(d2);
		E d1rep = findRep(d1);
		E d2rep = findRep(d2);
		if(d1Node.rank > d2Node.rank) {
			set.get(d2rep).parent = d1rep;
			d1Node.rank++;
			}
		else if(d1Node.rank < d2Node.rank) {
			set.get(d1rep).parent = d2rep;
			d2Node.rank++;
			}
		else if (d1Node.rank == d2Node.rank) {
			set.get(d1rep).parent = d2rep;
			d2Node.rank++;
		}
	}
	
	
	/**
	 * class to create nodes in a DisjointedSet
	 */
	private class DSNode<E> {
		//member variables
		protected E data;
		protected E parent;
		protected int rank;
		
		/**
		 * construct a DSNode using the given data/ initial parent
		 * @param d    given data and initial parent
		 */
		public DSNode(E d) {
			data = d;
			parent = d;
			rank = 0;
		}
	}
}
