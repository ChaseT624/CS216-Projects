import java.io.FileNotFoundException;

public class GraphTest {
	
	   public static void main(String[] args) throws FileNotFoundException {
	        String vfile, efile;
	 
	        // if 2 filenames are given: vertex file, edge file
	        // e.g., java GraphTest g1_labels g1_w
	        if (args.length == 2) {
	            vfile = args[0];
	            efile = args[1];
	        }
	 
	        // if graph # is given
	        // e.g., java GraphTest 5   (for graph5)
	        else if (args.length == 1) {
	            int num = Integer.parseInt(args[0]);
	            vfile = "g" + num + "_labels";
	            efile = "g" + num + "_w";
	        }
	 
	        // if no graph is specified, run algorithms on graph 1
	        // e.g., java GraphTest
	        else {
	            vfile = "g1_labels";
	            efile = "g1_w";
	        }
	 
	        Graph g = new Graph(vfile, efile);
	        runAlgorithms(g);
	       
	 
	        // if no graph # is given, run the algorithms on all graphs (graph 1 ~ 23)
	        // e.g., java GraphTest
	        /*
	        if (args.length == 0) {
	            for (int i = 2; i < 24; ++i) {
	                vfile = "g" + i + "_labels";
	                efile = "g" + i + "_w";
	                g = new Graph(vfile, efile);
	                runAlgorithms(g);
	            }
	        }*/
	    }
	   
	   public static void runAlgorithms(Graph g) {
		   System.out.print(g);
		   System.out.println();
		   for (int i = 0; i < g.nVerts(); i++) {
			   GraphUtil.bfs(g, g.getVertex(i).label);
		   }
		   System.out.println();
		   for (int i = 0; i < g.nVerts(); i++) {
			   g.resetVerts();
			   System.out.print("dfs(" + g.getVertex(i).label + "): ");
			   GraphUtil.dfs(g, g.getVertex(i).label);
			   System.out.print("(done)\n");
		   }
		   System.out.println();
		   for (int i = 0; i < g.nVerts(); i++) {
			   GraphUtil.dijkstra(g, g.getVertex(i).label);
		   }
		   System.out.println();
		   for (int i = 0; i < g.nVerts(); i++) {
			   GraphUtil.prim(g, g.getVertex(i).label);
		   }
		   System.out.println();
		   GraphUtil.kruskal(g);

	   }
}