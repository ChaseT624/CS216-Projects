import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.TreeMap;

/**
 * Class name: GrapUtilh
 * Chase Tiberi
 * Hw10
 *
 * A class for traversing Graphs with algorithms*/
public class GraphUtil {
	
	/**
	 * use Breadth-First search and lists labels visited
	 * @param g      graph to be used
	 * @param src    starting vertex
	 */
	public static void bfs(Graph g, String src) {
		g.resetVerts();
		LinkedList<Vertex> q = new LinkedList<Vertex>();
		q.add(g.getVertex(src));
		g.getVertex(src).mark();
		String str = "bfs(" + src + "): ";
		while(!q.isEmpty()) {
			Vertex v = q.pollFirst();
			str += v.label + "-";
			//use string list of neighbors to see amount of neighbors and find them in the graph
			//using their string representation
			ArrayList<String> neigh = v.getNeighbors();	
			for (int i =0; i < neigh.size(); i++) {
				if (g.getVertex(neigh.get(i)).isMarked() == false) {
					q.add(g.getVertex(neigh.get(i)));
					g.getVertex(neigh.get(i)).mark();
				}
			}
		}
		System.out.println(str + "(done)");
	}
	
	/**
	 * use Depth-First search and lists labels visited
	 * @param g      graph to be used
	 * @param src    starting vertex
	 */
	public static void dfs (Graph g, String src){	
		System.out.print(src + "-");
		Vertex v = g.getVertex(src);
		v.mark();
		TreeMap<String, Edge> neigh = v.getAdj();
		Collection<Edge> c = neigh.values();
		for (Edge e: c) {
			if (!g.getVertex(e.getVdst().label).isMarked()) {
				dfs(g, g.getVertex(e.getVdst().label).label);
			}
		}
	}
	
	/**
	 * Removes and returns the smallest amount in an arrayList
	 * @param q        arrayList to remove from
	 * @return the removed vertex
	 */
	public static Vertex removeMin(LinkedList<Vertex> q) {
		Vertex min = null;
		int index = 0;
		for (int i =0; i < q.size(); i++) {
			if (i == 0) {
				min = q.get(i);
			}
			else {
				if (min.getCost() > q.get(i).getCost()) {
					min = q.get(i);
					index = i;
				}
			}
		}
		return q.remove(index);
	}
	
	/**
	 * uses Dijkstra algorithm to find shortest path to each vertex in graph from source
	 * @param g        graph to be used
	 * @param src      starting vertex
	 */
	public static void dijkstra(Graph g, String src) {
		g.resetVerts();
		for (int i = 0; i < g.nVerts(); i++) {
			g.getVertex(i).setCost(Double.POSITIVE_INFINITY);
		}
		LinkedList<Vertex> q = new LinkedList<Vertex>();
		q.add(g.getVertex(src));
		g.getVertex(src).mark();
		g.getVertex(src).setCost(0);
		while (!q.isEmpty()) {
			Vertex v = removeMin(q);
			ArrayList<String> neigh = v.getNeighbors();	
			v.mark();
			for (int i =0; i < neigh.size(); i++) {
				if (g.getVertex(neigh.get(i)).isMarked() == false && 
						g.getVertex(neigh.get(i)).getCost() > v.getCost() + g.getEdge(v, g.getVertex(neigh.get(i))).weight ) {
					q.add(g.getVertex(neigh.get(i)));
					g.getVertex(neigh.get(i)).setCost(v.getCost() + g.getEdge(v, g.getVertex(neigh.get(i))).weight);
					g.getVertex(neigh.get(i)).pred = v;
				}
				
			}
			
		}
		System.out.println("dijkstra's single-source shortest path from " + src);
		for (int i = 0; i < g.nVerts(); i++) {
			if (g.getVertex(i) != g.getVertex(src))
				printPath(g, src, g.getVertex(i).label);
		}	
	}
	
	/**
	 * prints the path from the source to the destination 
	 * @param g        graph to be used
	 * @param src      source vertex
	 * @param dst      destination vertex
	 */
	public static void printPath(Graph g, String src, String dst) {	
		String str = src + "-->" + dst +": ";
		LinkedList<Vertex> path = new LinkedList<Vertex>();
		Vertex pathFinder = g.getVertex(dst);
		str += "(" + pathFinder.getCost() + ") " + src + "-";
		while (pathFinder != g.getVertex(src)) {
			if (pathFinder.pred == null) {
				str = src + "-->" + dst +": no path";
				break;
			}
			path.addFirst(pathFinder);
			pathFinder = pathFinder.pred;
		}
		if (pathFinder == g.getVertex(src)) {
			while(!path.isEmpty()) {
				str += path.pollFirst().label + "-";
			}
			str+="(done)";
		}
		System.out.println(str);
	}
	
	/**
	 * applies prim's minimum spanning tree algorithm to the given graph 
	 * @param g      given graph 
	 * @param src    source vertex
	 */ 
	public static void prim(Graph g, String src) {
		g.resetVerts();
		g.toUndirected();
		double mstCost = 0;
		String str = "[";
		LinkedList<Vertex> q = new LinkedList<Vertex>();
		q.add(g.getVertex(src));
		g.getVertex(src).mark();
		while (q.size() != g.nVerts()) {
			Edge newE = findMinEdge(q, g);
			q.add(newE.getVdst());
			mstCost += newE.weight;
			if (q.size() < g.nVerts()) {
				str +=  newE + ", ";
			}
			else {
				str +=  newE + "";
			}
				
			newE.getVdst().mark();
		}
		System.out.println("prim(" + src + "): (" + mstCost + ") " + str + "]");
	}
	
	/**
	 * returns the smallest edge in an arrayList
	 * @param q        arrayList to remove from
	 * @return the smallest edge
	 */
	public static Edge findMinEdge(LinkedList<Vertex> q, Graph g) {
		//V made just to give a fake value so that the first time min is checked it isn't null pointer 
		Vertex V = new Vertex("Fake_Value", 1000);
		Edge min = new Edge(V, V, Double.POSITIVE_INFINITY); 
		EdgeLabelComp cmp = new EdgeLabelComp();
		for (Vertex v: q) {
			TreeMap<String, Edge> neigh = v.getAdj();
			Collection<Edge> c = neigh.values();
			for (Edge e: c) {
				Edge currE = g.getEdge(v.label, e.getVdst().label);
				if (!g.getVertex(e.getVdst().label).isMarked() && 
						currE.weight <= min.weight) {
					if (currE.weight == min.weight) {
						if (cmp.compare(currE , min) < 0) {
							min = currE;			
						}
					}
					else {
						min = currE;
					}
				}
			}
		}
		return min;
	}
	
	public static void kruskal(Graph g) {
		g.resetVerts();
		g.toUndirected();
		ArrayList<Edge> edges = g.getEdgesUndirected();
		DisjointSet<Vertex> verts = new DisjointSet<Vertex>(g.getVerts());
		String str = "[";
		double mstCost = 0; 
		int size = g.nVerts();
		StringComparator cmp = new StringComparator();
		while (!(size == 1)) {
			Edge currEdge = edges.remove(0);
			if(!(verts.findRep(currEdge.getVdst()).equals(verts.findRep(currEdge.getVsrc())))) {
				//check smaller alphabetically here before calling union 
				if (cmp.compare(currEdge.getVsrc().label, currEdge.getVdst().label) > 0) {
					verts.Union(currEdge.getVsrc(), currEdge.getVdst()); 
				}
				else {
					verts.Union(currEdge.getVdst(), currEdge.getVsrc()); 
				}
				mstCost += currEdge.weight;
				if (size == 2) {
					str += currEdge;
				}
				else  {
					str += currEdge + ", ";
				}
				size--;
				
			}
		}
		System.out.println("kruskal: (" + mstCost + ") " + str + "]");
	}
}
