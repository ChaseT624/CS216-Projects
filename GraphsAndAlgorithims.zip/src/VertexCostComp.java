import java.util.Comparator;

/**
 * Class name: VertexgetCostComp
 * Chase Tiberi
 * Hw9
 *
 * A class that compares the getCosts of vertices*/
public class VertexCostComp implements Comparator<Vertex> {

	/**
	 * compare and return the greater getCost of the vertices
	 * @param v1    vertex 1
	 * @param v2    vertex 2
	 * @return a value from 1 to -1 to show which value is larger
	 */
	public int compare(Vertex v1, Vertex v2) {
		if (v1.getCost() > v2.getCost()) {
			return 1;
		}
		else if (v1.getCost() == v2.getCost()) {
			return 0;
		}
		else {
			return -1;
		}
	}

}
