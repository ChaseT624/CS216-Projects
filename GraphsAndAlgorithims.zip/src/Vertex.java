import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeMap;
/**
 * Class name: Vertex
 * Chase Tiberi
 * Hw9
 *
 * A class of Vertex for Graphs */

public class Vertex {
	//member variables 
	protected int id;
	protected String label;
	protected Vertex pred;
	private double cost;
	private boolean visited;
	private ArrayList<String> neighbors;
	private TreeMap<String, Edge> adj;
	
	/**
	 * construct a vertex
	 * @param label    the string label
	 * @param id       the vertex id
	 */
	public Vertex(String label, int id) {
		this.id = id;
		this.label = label;
		pred = null;
		cost = 0;
		visited = false;
		neighbors = new ArrayList<String>();
		adj = new TreeMap<String, Edge>(new StringComparator());
	}
	
	/**
	 * resets the vertex for algorithms 
	 */
	public void reset() {
		visited = false;
		cost = 0;
		pred = null;
	}
	
	/**
	 * mark visited true
	 */
	public void mark() {
		visited = true;
	}
	
	/**
	 * mark visited false
	 */
	public void unmark() {
		visited = false;
	}
	
	/**
	 * takes in a cost and sets this vertex cost
	 * @param c    cost to be set
	 */
	public void setCost(double c){
		cost = c;
	}
	
	/**
	 * returns the cost of the vertex
	 * @return the cost of the vertex
	 */
	public double getCost() {
		return cost;
	}
	
	/**
	 * takes in a cost and adds to this vertex cost
	 * @param c    cost to be added
	 */
	public void addCost(double c) {
		cost += c;
	}
	
	/**
	 * checks to see if this vertex has been visited
	 * @return true if it has been, false if not
	 */
	public boolean isMarked() {
		return (visited == true);
	}
	
	/**
	 * get and return number of neighbors
	 * @return number of neighbors
	 */
	public int getAdjSize() {
		return adj.size();
	}
	
	/**
	 * return the adjacency list
	 * @return the adjacency list
	 */
	public TreeMap<String, Edge>getAdj() {
		return adj;
	}
	
	/**
	 * find and return the edge connecting this vertex to the one provided
	 * @param dst      label of Vertex to be connected to this one
	 * @return the edge connecting the two, null if there is no such edge
	 */
	public Edge getAdj(String dst) {
		if (adj.get(dst) != null) {
			return adj.get(dst);
		}
		return null;
	}
	
	/**
	 * makes and returns a string of this vertex
	 * @return a string of this vertex;
	 */
	public String toString() {
		String str = label + " (" + id + ", " + adj.size() + "):";
		for (int i = 0; i < adj.size(); i++) {
			if (adj.get(neighbors.get(i)) != null) {
				str += neighbors.get(i) + " (" + adj.get(neighbors.get(i)).weight +") ";	
			}
		}
		return str;
	}
	
	/**
	 * create and add a new edge using the parameters
	 * @param vdst      destination of new edge
	 * @param w         weight of edge
	 */
	public void addAdj(Vertex vdst, double w) {
		addAdj(new Edge(this, vdst, w));
		
	}
	
	/**
	 * add this edge to the adjacency list
	 * @param e      edge to be added
	 */
	public void addAdj(Edge e) {
		adj.put(e.getVdst().label, e);
		int index = 0;
		StringComparator s = new StringComparator();
		if (neighbors.size() == 0) {
			neighbors.add(e.getVdst().label);
		}
		else {
			while(index < neighbors.size() && s.compare(e.getVdst().label, neighbors.get(index)) > 0) {
				index++;
			}
			neighbors.add(index, e.getVdst().label);
		}
	}
	
	/**
	 * returns the arrayList of the strings of the neighbors
	 * @return the arrayList of the strings of the neighbors
	 */
	public ArrayList<String> getNeighbors() {
		return neighbors;
	}
}
