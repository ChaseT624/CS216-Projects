import java.util.Comparator;

/**
 * Class name: EdgeWeightComp
 * Chase Tiberi
 * Hw9
 *
 * A class that compares weights of edges */
public class EdgeWeightComp implements Comparator<Edge> {

	/**
	 * compare and return the greater weight
	 * @param d1    edge 1
	 * @param d2    edge 2
	 * @return a value from 1 to -1 to show which value is larger
	 */
	public int compare(Edge e1, Edge e2) {
		if (e1.weight > e2.weight) {
			return 1;
		}
		else if (e1.weight == e2.weight) {
			return 0;
		}
		else {
			return -1;
		}
	}

}
