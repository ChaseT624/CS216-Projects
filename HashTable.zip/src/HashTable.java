import java.text.DecimalFormat;

/**
 * Class name: HashTable
 * Chase Tiberi
 * Hw4
 *
 * A HashTable class that uses quadratic probing
 */
public class HashTable<K, V> {
	//member variables 
	private HashEntry<K,V>[] table; 
	private int capacity; 
	private double maxLoadFactor; 
	private int count;
	//constants
	private final HashEntry<K,V> DEL = new HashEntry<K,V>(null, null);
	private static final int DEFAULT_CAP = 7;
	private static final double DEFAULT_MAXLF = 0.5;
	
	/**
	 * constructor to initialize capacity and maxLoadFactor to default values 
	 * by calling another constructor
	 */
	public HashTable() {
		this(DEFAULT_CAP, DEFAULT_MAXLF);
	}
	
	/**
	 * constructor to initialize capacity to default value and maxLoadFactor to the specified amount
	 * by calling another constructor
	 * @param lf        maxLoadFactor to be initialized
	 */
	public HashTable(double lf) {
		this(DEFAULT_CAP, lf);
	}
	
	/**
	 * constructor to initialize maxLoadFactor to default value and capacity to the specified amount
	 * by calling another constructor
	 * @param cap      capacity to be initialized
	 */
	public HashTable(int cap) {
		this(cap, DEFAULT_MAXLF);
	}
	
	/**
	 * constructor to initialize initial capacity and the max load factor 
	 * as well as the table, current loadFactor and count
	 * @param cap      initial capacity to be initialized
	 * @param lf       max load factor to be initialized
	 */
	public HashTable (int cap, double lf) {
		capacity = cap;
		maxLoadFactor = lf;
		count = 0;
		table = (HashEntry<K,V>[]) new HashEntry[cap];
		
	}
	
	/**
	 * Hashes the given key using java's hash method and returns the hashed key % table.length
	 * @param key      the key to be hashed
	 * @return the hashed key % table.length
	 */
	public int hash(K key) {
		//return (Math.abs(key.hashCode()) % table.length) ;	
		//This return statement used for the sample output test
		return key.toString().length() % table.length;
	}
	
	/**
	 * If the table already contains the key the value is replaced, 
	 * if not a new HashEntry(key, value) is added to the list
	 * @param key       key to either replace its old value or add a new value
	 * @param value     value to replace old value or new value to be put with a new key
	 * @return  old value if value is replaced, null if it is a new key
	 */
	public V put(K key, V value) {
		int size2 = count + 1;
		double lf = ((double) size2 / table.length);
		if (lf > maxLoadFactor) {
			resize();
		}
		HashEntry<K, V> entry = new HashEntry<K,V>(value, key);
		int hashI = hash(key);
		//hashF means hashFinal and is used to store the original hashIndex
		//because I change the original HashI to only use one loop
		int hashF = hashI;
		int size = table.length;
		int n = 0;
		//Hold used to hold the location of a deleted space
		int hold = -1;
		for(int i = hashI; i < size;) {
			//Test printing to show the sample output example
			//System.out.println("for " + key + " check " + hashF + " +" + n+"^2 " + "=" + i);
			//check to see if hold == -1 so that there isn't a DEL spot closer to the 
			//original HashI than the first fully open spot
			if (table[i] == null && hold == -1) {
				table[i] = entry;
				count++;
				return null;
			}
			//check to see if hold == -1 so that we know it is the first DEL spot
			if(table[i] == DEL && hold == -1) {
				hold = i;
			}
			//check if table is not DEL and not null because if could still be null
			//and not checked for in the first if statement because hold != -1
			if (table[i] != DEL && table[i] != null) {
				if(key.equals(table[i].key)) {
					V tmp = table[i].value;
					table[i].value = value;
					return tmp;
				}		
			}
			n++;
			int next = (int) (hashF + Math.pow(n, 2));
			//if the next index to check is greater than the size of the list use the modulus
			//and set the size now equal to original hashI to check the part of the list we missed
			if (next >= table.length) {
				size = hashI; 
				i = next % table.length;
				}
			else {
				i = next;
			}
			
		}
	   //if an item was placed into hold the HashEntry will be placed at the first DEL spot
		if (hold != -1) {
	    	table[hold] = entry;
			count++;
			return null;
	    }
	   //if no open space found must resize the list and then call the put method again,
	   //the return statement is only there to compile
	    else {
	    	resize();
		    put(key, value);
		    return null;
	    }
	}
	/**
	 * checks to see if the key provided is within the list
	 * @param key     key being checked to see if it is in the list
	 * @return true if key is in the list, false if not
	 */
	public boolean containsKey(K key) {
		//use indexOf to see if key is in the list and return true if so
		int index = indexOf(key);
		if (index == -1) {
			return false;
		}
		else {
			return true;
		}	
	}
	
	/**
	 * checks to see if the value provided is within the list
	 * @param value     value being checked to see if it is in the list
	 * @return true if value is in the list, false if not
	 */
	public boolean containsValue(V value) {
		//need to check the whole list without a key
		for (int i = 0; i < table.length; i++) {
			if (table[i] != null && value.equals(table[i].value)) {
				return true;
			}		
		}
		return false;
	}
	/**
	 * returns the value whose key matches the given key
	 * @param key     key whose value were looking for
	 * @return the value of the given key, return null if key is not in list
	 */
	public V get(K key) {
		//use indexOf to see if key is in the list and if so use the index for the value
		int index = indexOf(key);
		if (index == -1) {
			return null;
		}
		else {
			return table[index].value;
		}
	}
	
	/**
	 * deletes the entry at the given key and replaces it with a DEL marker
	 * @param key     key where entry should be removed
	 * @return the removed value, null if the key isn't in the list
	 */
	public V remove(K key) {
		//use indexOf to see if key is in the list and if so use the index to remove the HashEntry
		int index = indexOf(key);
		if (index == -1) {
			return null;
		}
		else {
			count--;
			V val = table[index].value;
			table[index] = DEL;
			return val;
		}
	}
	
	/**
	 * returns the amount of HashEntries in the list
	 * @return amount of HashEntries in the list
	 */
	public int size() {
		return count;
	}
	
	/**
	 * checks to see if the list is empty
	 * @return true f the list is empty, false if not
	 */
	public boolean empty(){
		return (count == 0);
	}
	/**
	 * clears the contents of the list
	 */
	public void clear() {
	for (int i = 0; i < table.length; i++) {
		table[i] = null;
	}
	count = 0;
	}
	
	/**
	 * creates a String with the contents of the HashTable
	 */
	public String toString() {
		String str = "";
		double lf = ((double) count / table.length);
		//allows for printing load factor as only two decimals
		DecimalFormat df = new DecimalFormat("0.00");
		if (empty()) {
			return str;
		}
        str += "load factor: " + df.format(lf) + "\n";
        str += "max load factor: " + maxLoadFactor + "\n";
        str += "current size: " + count + "\n\n";
        int i =0;
        for (HashEntry<K, V> entry: table) {
            if(!(entry == null)) {
                str += i + ": ";
                if(entry == DEL) {
                    str += "DELETED\n";
                }
                else {
                    str += entry + "\n";
                }
            }
        i++;
        }
        return str;
	}
	
	/**
	 * checks for the index in the table of the given key
	 * @param key      the key whose index were looking for
	 * @return the index where the key is located, -1 if the key isn't in this list
	 */
	private int indexOf(K key) {
		int hashI = hash(key);
		//hashF means hashFinal and is used to store the original hashIndex
		//because I change the original HashI to only use one loop
		int hashF = hashI;
		int size = table.length;
		int n = 0;		
		for(int i = hashI; i < size;) {
			if (table[i] == null) {
				return -1;
				}
			if(table[i] != DEL) {
				if(key.equals(table[i].key)) {
					return i;			
					}		
			}
			++n;
			int next = (int) (hashF + Math.pow(n, 2));
			//if the next index to check is greater than the size of the list use the modulus
			//and set the size now equal to original hashI to check the part of the list we missed
			if (next >= table.length) {
				i = next % table.length;
				size = hashI; 
				}
			else  {
				i = next;
			}
		}		
		return -1;
	}
	
	/**
	 * checks to see if the number given is prime
	 * @param p     number to check if prime
	 * @return true if number is prime, false if not
	 */
	private boolean isPrime(int p) {
		//starting at 2 and ending before the number lets us see if the number is prime,
		//because if its prime it wont be divisible by anything by 1 or itself which 
		//aren't included in the check
		for (int i = 2; i < p; i++) {
			if(p % i==0) {
				return false;
			}
		}
		return true;
	}
	/**
	 * increases the size of the table and copies the old list into the new one
	 */
	private void resize() {	
		int newSize = table.length * 2;
		boolean found = false;
		int size = count;
		//use isPrime to find the next prime number after doubling the list
		while(!found) {
			if (isPrime(++newSize)) {
				found = true;
			}
		}
		HashEntry<K,V>[] newTable = (HashEntry<K,V>[]) new HashEntry[newSize];
		HashEntry<K,V>[] tmp = table;
		table = newTable;
		capacity = table.length;
		for (int i =0; i < tmp.length; i++) {
			//check to see if a HashEntry is in this index of the list 
			if (tmp[i] != null && tmp[i] != DEL) {
				//rehash all previous HashEntries
				put(tmp[i].key, tmp[i].value);
			}
			else {
				newTable[i] = table[i];
			}
		}
		count = size;
	}
	
	/**
	 * returns the capacity
	 * @return the capacity
	 */
	public int getCapacity() {
		return capacity;
	}
	/**
	 * returns the maxLoadFactor
	 * @return the maxLoadFactor
	 */
	public double getMaxLF() {
		return maxLoadFactor;
	}
	/**
	 * private class to make an HashEntry for the list
	 */
	private class HashEntry<K,V> {
		public V value;
		public K key; 
		
		/**
		 * initialize a HashEntry with the given value and key
		 * @param v     value to be initialized 
		 * @param k     key to be initialized
		 */
		public HashEntry(V v, K k) {
			value = v;
			key = k;
		}
	
		/**
		 * returns a string of a single HashEntry
		 */
		public String toString() {
			return  key + ", " + value;
		}
	}
}

