
public class Tester {

	
	public static void main(String[] args) {
		HashTable<String, Integer> test1 = new HashTable<String, Integer>(5);
		
		test1.put("alex", 1);
		test1.put("tony", 2);
		System.out.println(test1);
		test1.put("brandon", 3);
		test1.put("ogden", 4);
		test1.put("Hannah", 5);
		test1.put("Mateus", 6);
		test1.put("Orrin", 7);
		test1.put("Andeuluza", 8);
		test1.put("Wil", 9);
		test1.put("liam", 4);
		test1.put("alex", 11);
		test1.put("Issac", 12);
		test1.put("Jenna", 13);
		test1.put("Chase", 14);
		test1.put("Nate", 15);
		test1.remove("alex");
		test1.remove("tony");
		test1.remove("brandon");
		test1.remove("ogden");
		test1.remove("Hannah");
		test1.remove("Mateus");
		test1.remove("Orrin");
		test1.remove("Andeuluza");
		test1.remove("Wil");
		test1.remove("liam");
		test1.remove("Alex");
		test1.remove("Issac");
		test1.remove("Jenna");
		test1.remove("Chase");
		System.out.println(test1);
		test1.remove("Nate");
		test1.put("Chase", 14);
		System.out.println(test1.getCapacity());
		System.out.println(test1);
		
		
		
		
		
		
		
		
		
		
		/*test1.put("first", 1);
		test1.put("second", 1);
		test1.put("third", 1);
		System.out.println(test1);
		test1.put("first", 1);
		//System.out.println(test1.get("first"));
		test1.put("second", 1);
		test1.put("third", 1);
		test1.remove("second");
		System.out.println(test1);
		test1.put("second", 1);
		test1.put("fourth", 1);
		test1.put("fifth", 1);
		System.out.println(test1);
		test1.remove("first");
		test1.remove("third");
		test1.remove("fourth");
		test1.put("sixth", 1);
		test1.put("seventh", 1);
		test1.put("sixth", 4);
		test1.put("fourth", 3);
		test1.put("seve", 1);
		test1.put("sith", 4);
		test1.put("fouh", 3);
		test1.remove("fouh");
		test1.remove("notan indez");
		test1.remove("seve");
		test1.put("sixthg", 1);
		test1.put("sevength", 1);
		test1.put("sixth", 4);
		test1.put("fougrth", 3);
		test1.put("segve", 1);
		test1.put("sigth", 4);
		test1.put("fgouh", 3);
		//test1.clear();
		//System.out.println(test1.empty());
		System.out.println(test1);*/
	}
}
