import static org.junit.Assert.*;

import org.junit.Test;

public class HashTableTest {
	private HashTable<String, Integer> test1 = new HashTable<String, Integer>();
	private HashTable<String, Integer> test2;

	
	
	@Test
	public void testHashTable() {
		test2 = new HashTable<String, Integer>();
		assertEquals(0.5, test2.getMaxLF(), 0);
		assertEquals(7, test2.getCapacity());
		
	}

	@Test
	public void testHashTableDouble() {
		test2 = new HashTable<String, Integer>(0.7);
		assertEquals(0.7, test2.getMaxLF(), 0);
		assertEquals(7, test2.getCapacity());
	}

	@Test
	public void testHashTableInt() {
		test2 = new HashTable<String, Integer>(13);
		assertEquals(0.5, test2.getMaxLF(), 0);
		assertEquals(13, test2.getCapacity());
	}

	@Test
	public void testHashTableIntDouble() {
		test2 = new HashTable<String, Integer>(13, 0.7);
		assertEquals(0.7, test2.getMaxLF(), 0);
		assertEquals(13, test2.getCapacity());
	}

	@Test
	public void testHash() {
		assertTrue("Returns  true if the hash is greater than 0", test1.hash("first") > 0);
		assertTrue("Returns  true if the hash is greater than 0", test1.hash("second") > 0);
		assertTrue("Returns  true if the hash is greater than 0", test1.hash("third") > 0);
	}

	@Test
	public void testPut() {
		assertEquals("", test1.toString());
		test1.put("first", 1);
		assertEquals("load factor: 0.14\nmax load factor: 0.5\ncurrent size: 1\n\n5: first, 1\n"
				,test1.toString());
		test1.put("second", 2);
		assertEquals("load factor: 0.29\nmax load factor: 0.5\ncurrent size: 2\n\n5: first, 1\n"
				+ "6: second, 2\n", test1.toString());
		test1.put("third", 3);
		assertEquals("load factor: 0.43\nmax load factor: 0.5\ncurrent size: 3\n\n4: third, 3\n"
				+ "5: first, 1\n6: second, 2\n", test1.toString());
	}

	@Test
	public void testContainsKey() {
		test1.put("first", 1);
		test1.put("second", 2);
		test1.put("third", 3);
		assertTrue("Will return true if the table contains this key", test1.containsKey("first"));
		assertFalse("Will return false if this table doesn't contain the key", test1.containsKey("fourth"));
	}

	@Test
	public void testContainsValue() {
		test1.put("first", 1);
		test1.put("second", 2);
		test1.put("third", 3);
		assertTrue("Will return true if the table contains this value", test1.containsValue(1));
		assertFalse("Will return false if this table doesn't contain the key", test1.containsValue(4));
	}

	@Test
	public void testGet() {
		test1.put("first", 1);
		test1.put("second", 2);
		test1.put("third", 3);
		int getV = test1.get("first");
		assertEquals(1, getV);
		getV = test1.get("second");
		assertEquals(2, getV);
		getV = test1.get("third");
		assertEquals(3, getV);	
	}

	@Test
	public void testRemove() {
		test1.put("first", 1);
		test1.put("second", 2);
		test1.put("third", 3);
		assertEquals(3, test1.size());
		assertEquals("load factor: 0.43\nmax load factor: 0.5\ncurrent size: 3\n\n4: third, 3\n"
				+ "5: first, 1\n6: second, 2\n", test1.toString());
		test1.remove("second");
		assertEquals(2, test1.size());
		assertEquals("load factor: 0.29\nmax load factor: 0.5\ncurrent size: 2\n\n4: third, 3\n"
				+ "5: first, 1\n6: DELETED\n", test1.toString());
		test1.remove("first");
		assertEquals(1, test1.size());
		assertEquals("load factor: 0.14\nmax load factor: 0.5\ncurrent size: 1\n\n4: third, 3\n"
				+ "5: DELETED\n6: DELETED\n", test1.toString());
		test1.remove("third");
		assertEquals(0, test1.size());
		assertEquals("", test1.toString());
		assertTrue("Returns true if the list is empty", test1.empty());
	}

	@Test
	public void testSize() {
		assertEquals(0, test1.size());
		test1.put("first", 1);
		test1.put("second", 2);
		test1.put("third", 3);
		assertEquals(3, test1.size());	
	}

	@Test
	public void testEmpty() {
		assertTrue("Returns true if the list is empty", test1.empty());
		test1.put("first", 1);
		test1.put("second", 2);
		test1.put("third", 3);
		assertFalse("Returns true if the list isn't empty", test1.empty());
		test1.clear();
		assertEquals("", test1.toString());
	}

	@Test
	public void testClear() {
		test1.put("first", 1);
		test1.put("second", 2);
		test1.put("third", 3);
		test1.clear();
		assertTrue("Returns true if the list is empty", test1.empty());
		assertEquals("", test1.toString());
	}

	@Test
	public void testToString() {
		assertEquals("", test1.toString());
		test1.put("first", 1);
		test1.put("second", 2);
		test1.put("third", 3);
		assertEquals("load factor: 0.43\nmax load factor: 0.5\ncurrent size: 3\n\n4: third, 3\n"
				+ "5: first, 1\n6: second, 2\n", test1.toString());
		test1.remove("second");
		assertEquals("load factor: 0.29\nmax load factor: 0.5\ncurrent size: 2\n\n4: third, 3\n"
				+ "5: first, 1\n6: DELETED\n", test1.toString());
		test1.clear();
		assertEquals("", test1.toString());
		
	}
	
	@Test
	public void testResize(){
		assertEquals(7, test1.getCapacity());
		test1.put("first", 1);
		test1.put("second", 2);
		test1.put("third", 3);
		test1.put("fourth", 4);
		assertEquals(17,test1.getCapacity());
	}
	@Test
	public void testGetCapacity() {
		assertEquals(7, test1.getCapacity());
		test1.put("first", 1);
		test1.put("second", 2);
		test1.put("third", 3);
		test1.put("fourth", 4);
		assertEquals(17, test1.getCapacity());
	}
	@Test
	public void testGetMaxLF() {
		assertEquals(0.5, test1.getMaxLF(),0);
		test2 = new HashTable<String, Integer>(0.7);
		assertEquals(0.7, test2.getMaxLF(),0);
		
	}
}
