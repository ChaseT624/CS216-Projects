
public class BTreeTest {
	public static void main(String[] args) {
		IntegerComparator in = new IntegerComparator();
		
		
		//Data taken from first sample text output on Assignment page
		BTree<Integer> n3 = new BTree<Integer>(in, 3);
		Integer[]   data1 = {50, 5, 30, 20, 3, 10, 60, 27, 19, 34, 45, 58, 18, 28, 38, 48, 25, 88, 40, 23, 26};
		for (int i = 0; i < data1.length; i++) {
			n3.add(data1[i]);
		}
		System.out.println("BTree with a degree of 3:\n" +n3);
		System.out.println("Root contains 17?: " + n3.getRoot().contains(17));
		System.out.println("Child [50] contains 50?: " + n3.getRoot().getChild(1).contains(50));
		System.out.println();
		
		//Data taken from sample provided in link next to split and add methods in the Assignment page
		BTree<Integer> n = new BTree<Integer>(in, 4);
		n.add(40);
		n.add(3);
		n.add(17);
		n.add(2);
		n.add(9);
		n.add(5);
		n.add(25);	
		n.add(10);
		n.add(8);
		n.add(50);
		n.add(93);
		n.add(100);
		n.add(95);
		n.add(6);
		System.out.println("BTree with a degree of 4:\n" +n);
		System.out.println("Root contains 17?: " + n.getRoot().contains(17));
		System.out.println("Child [5 9] contains 9?: " + n.getRoot().getChild(0).contains(9));
		System.out.println("Child [5 9] contains 18?: " + n.getRoot().getChild(0).contains(18));
		System.out.println();
		
		 Character[] data2 = {'Z', 'Y', 'X', 'W', 'V', 'U', 'T', 'S', 'R', 'Q', 'P', 'O', 'N', 
                 'M', 'L', 'K', 'J', 'I', 'H', 'G', 'F', 'E', 'D', 'C', 'B', 'A'};

		 //data taken from sample output for a tree of size 5
		 BTree<Character> n2 = new BTree<Character>(new CharComparator(), 5);
		 for (int i = 0; i < data2.length; i++) {
			 n2.add(data2[i]);
		 }
		 System.out.println("BTree with a degree of 5:\n" +n2);
		 System.out.println("Root contains I?: " + n2.getRoot().contains('I'));
		 System.out.println("Child [A B]  contains B?: " + n2.getRoot().getChild(0).getChild(0).contains('B'));
		 System.out.println("Child [A B] contains F?: " + n2.getRoot().getChild(0).getChild(0).contains('F'));
	}
}
