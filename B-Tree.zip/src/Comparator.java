public interface Comparator<E> {
	public int compare(E d1, E d2);
}
