import java.util.LinkedList;

/**
 * Class name: BTree
 * Chase Tiberi
 * Hw7
 *
 * A B-Tree of any degree  */
public class BTree<E> {
	//member variables 
	private BTreeNode<E> root;
	private int degree;
	private Comparator<E> cmp;
	
	/**
	 * Construct a new BTree
	 * @param c    comparator to be initialized
	 * @param deg  degree to be initialized
	 */
	public BTree(Comparator<E> c, int deg) {
		cmp = c;
		degree = deg;
		root = new BTreeNode<E>(null, c, deg);
	}
	
	/**
	 * look through values in ptr to see where child that has target might belong
	 * @param ptr    node to look through
	 * @return child target might belong to, null if ptr is a leaf
	 */
	public BTreeNode<E> stepDown(BTreeNode<E> ptr, E target) {
		if (ptr.isLeaf()) {
			return null;
		}
		else {
			int index = 0;
			while (index < ptr.size() && cmp.compare(target, ptr.getData(index)) > 0) {
				index++;
			}
			return ptr.getChild(index);
			
		}
	}
	
	/**
	 * find and return leaf node that target should be added to or belong to 
	 * @return leaf node target should be added to or belong to
	 */
	public BTreeNode<E> findLeaf(E target) {
		BTreeNode<E> ptr = root;
		while (!ptr.isLeaf()) {
			ptr = stepDown(ptr, target);
		}
		return ptr;
	}
	
	
	/**
	 * add data to the tree
	 * @param data  data to be added
	 */
	public void add (E data) {
		BTreeNode<E> addTo = findLeaf(data);
		BTreeNode<E> posRoot = addTo.add(data);
		if (posRoot != null) {
			root = posRoot;
		}
	}
	
	/**
	 * find the node containing the target 
	 * @param target  target being looked for
	 * @return the node with the target, null if it doesn't exist
	 */
	private BTreeNode<E> getNode(E target) {
		if (root.contains(target)) {
			return root;
		} 
		else {
			BTreeNode<E> ptr = stepDown(root, target);
			while (ptr != null) {
				if (ptr.contains(target)) {
					return ptr;
				}
				ptr = stepDown(ptr, target);
			}
			return null;
		}
	}
	
	/**
	 * create and return a String of the tree in level order
	 * @return a string of the tree in level order
	 */
	public String toString() {
		return levelOrder(root);
	}
	
	private String levelOrder(BTreeNode<E> ptr) {
		 LinkedList<BTreeNode<E>> q = new LinkedList<BTreeNode<E>>();
	     String str = "";
	     if (ptr != null) {
	     q.addLast(ptr);
	     }
         while (!q.isEmpty()) {
        	BTreeNode<E> current = q.pollFirst();
	        str += current.toString();
	        if (!current.isLeaf()) {
	        	int chiSize = current.childNum();
	        	for (int i = 0; i < chiSize; i++) {
	        		q.addLast(current.getChild(i));
	        	}
	        	
	        }
	      }
         return str;
	}
	/**
	 * return the degree of the list
	 * @return the degree of the list
	 */
	public int getDegree() {
		return degree;
	}
	
	/**
	 * return the root of the tree
	 * @return the root of the tree
	 */
	public BTreeNode<E> getRoot() {
		return root;
	}
	
}
