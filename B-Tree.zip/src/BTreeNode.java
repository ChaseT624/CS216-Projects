import java.util.ArrayList;
import java.util.List;

public class BTreeNode<E> {
	//Member Variables 
	private BTreeNode<E> parent;
	private Comparator<E> cmp;
	private int degree;
	private ArrayList<E> data;
	private ArrayList<BTreeNode<E>> children;
	
	/**
	 * Construct a BTreeNode
	 * @param p   the parent node
	 * @param c   the comparator used to order the data
	 * @param d   the degree of the node
	 */
	public BTreeNode(BTreeNode<E> p, Comparator<E> c, int d) {
		parent = p;
		cmp = c;
		degree = d;
		data = new ArrayList<E>();
		children = new ArrayList<BTreeNode<E>>();
	}
	
	/**
	 * create and return a string of the node
	 * @return a string of the node
	 */
	public String toString() {
		String str = "[ ";
		for (int i = 0; i < data.size(); i++) {
			str += data.get(i) + " ";
		}
		str+= "]";
		return str;
	}
	
	/**
	 * checks and returns whether or not this node is a leaf
	 * @return true if it is a leaf, false if not
	 */
	public boolean isLeaf() {
		return (children.size() == 0);
	}
	
	/**
	 * adds a new child to the end of node
	 * @param newChild   child to add to the node
	 */
	public void addChild(BTreeNode<E> newChild) {
		newChild.parent = this;
		children.add(newChild);
	}
	
	/**
	 * adds new child to the node in the correct order
	 * @param newChild    child to be added
	 */
	public void addChildOrdered(BTreeNode<E> newChild) {
		newChild.parent = this;
		int index = 0;
		while( index < children.size() && cmp.compare(newChild.data.get(0), this.getChild(index).getData(0)) > 0) {
			index++;
			}
		children.add(index, newChild);
	}
	
	/**
	 * adds new children to the node
	 * @param newChildren   children to be added to the node
	 */
	public void setChildren(List<BTreeNode<E>> newChildren) {	
		for (int i = 0; i < newChildren.size(); i++) {
			BTreeNode<E> child = newChildren.remove(i);
			addChild(child);
		}
	}
	
	/**
	 * find and return the child node at the given position 
	 * @param pos    position to return child from
	 * @return the node at the given position, or null if there is nothing there
	 */
	public BTreeNode<E> getChild(int pos) {
		return children.get(pos);
	}
	
	/**
	 * return the number of data in this node
	 * @return number of data in this node
	 */
	public int size() {
		return data.size();
	}
	
	public ArrayList<E> getData() {
		return data;
	}
	public ArrayList<E> getChildren() {
		return (ArrayList<E>) children;
	}
	public int getDegree() {
		return degree;
	}
	/**
	 * return the number of children
	 * @return the number of children
	 */
	public int childNum() {
		return children.size();
	}
	/**
	 * return the data at this position in the node
	 * @param pos    position to get the data from
	 * @return the data found, or null if no data exists
	 */
	public E getData(int pos) {
		E target = data.get(pos);
		if (target == null) {
			return null;
		}
		return target;
	}
	
	/**
	 * set this list of data into the node
	 * @param newDataSet   list of data to be set into the node
	 */
	public void setData(List<E> newDataSet) {
		data.addAll(newDataSet);
	}
	
	/**
	 * checks to see if the target data is in this node
	 * @param target   data being looked for
	 * @return true if data is in list, false if not
	 */
	public boolean contains(E target) {
		if (indexOf(target) != -1) {
			return true;
		}
		return false;
	}
	
	/**
	 * checks to see if target data is in this node and returns the position
	 * @param target    data being looked for
	 * @return the position, or -1 if the data isn't in the node
	 */
	public int indexOf(E target) {
		int min = 0;
		int max = data.size()-1;
		while (min <= max) {
			int mid = (min +max) /2;
			 if (target == data.get(mid)) {
				 return mid;
			 }
			 else if (cmp.compare(target, data.get(mid)) > 0) {
				 min = mid +1;
			 }
			 else {
				 max = mid -1;
			 }	        
		}
		return -1;
	}
	
	/**
	 * checks to see if there are too many children or data in this node
	 * @return true if too many, false if not
	 */
	public boolean isOverflow() {
		return (data.size() >= degree || children.size() > degree);
	}
	
	/**
	 * checks to see if there are not enough children or data in this node
	 * @return true if not enough, false if not
	 */
	public boolean isUnderFlow() {
		return (data.size() < degree || children.size() > Math.ceil(degree/2));
	}
	
	/**
	 * handles the overflow of a node 
	 * @return new parent created
	 */
	private BTreeNode<E> split() {
		BTreeNode<E> right = new BTreeNode<E>(null, cmp, degree);
		int dataSize = data.size();
		int midIndex = data.size()/2;
		for (int i = midIndex+1; i < dataSize; i++) {
			right.data.add(data.remove((midIndex+ 1)));
		}
		if (!isLeaf()) {
			int chilSize = children.size();
			for (int i = midIndex+1; i < chilSize; i++) {
				right.addChild(children.remove((midIndex+1)));
			}
		}
		BTreeNode<E> newPar = new BTreeNode<E>(null, cmp, degree);
		if (parent == null) {
			parent = newPar;
			newPar.addChild(this); 
		}
		parent.addChildOrdered(right);
		right.parent = parent;
		//In here for testing purposes 
		//System.out.println("Overflow --> " + data.get(midIndex) + " must be promoted.");
		BTreeNode<E> addVal = parent.add(data.get(midIndex));
		data.remove(midIndex);
		if(newPar.size() != 0) {
			return parent;
		}
		if (parent.isOverflow()) {	
			return parent.split();
		}
		return addVal;
	}
	
	/**
	 * find the position to insert the data 
	 * @param target    target being inserted
	 * @return the index to add the data
	 */
	public int findInsertPos(E target) {
		int index = 0;
		if (data.size() != 0) {
			while(index < data.size() && cmp.compare(target, data.get(index)) > 0) {
				index++;
				}
			}
		return index;
	}
	
	/**
	 * add the data here to the right place in the array list 
	 * @param d    data to be added
	 * @return null if no split, new parent node if split
	 */
	public BTreeNode<E> add(E d) {
		data.add(findInsertPos(d), d);
		if (isOverflow()) {
			return split();
		}
		return null;
	}
		
}
