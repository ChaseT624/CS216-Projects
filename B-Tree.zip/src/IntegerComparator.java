
public class IntegerComparator implements Comparator<Integer> {

	@Override
	public int compare(Integer d1, Integer d2) {
		return(d1.compareTo(d2)) ;
	}

}
