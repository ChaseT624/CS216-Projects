
public class CharComparator implements Comparator<Character> {

	@Override
	public int compare(Character d1, Character d2) {
		// TODO Auto-generated method stub
		return d1.compareTo(d2);
	}

}
